<#
.SYNOPSIS
Set-ADPicture.ps1
Written by Joakim at Jocha AB, http://jocha.se
Source= http://blog.jocha.se/tech/ad-user-pictures-in-windows-10
Author= Jesse Paxson on 2016-09-30 at 21:54 
Modified to work with Windows 10, build 1607, and to work with local accounts. 
Also added a function written by Michal Gajda of http://commandlinegeeks.com to properly size images.
.DESCRIPTION
Version 1.3 � Updated 2016-02-13
This script downloads and sets the Active Directory profile photograph and sets it as your profile picture in Windows.
Remember to create a defaultuser.jpg in \\domain\netlogon\
.VERSIONS
2016-09-30 : Updated to change image size, and to work with Windows 10 1607, and to work with local accounts. -Jesse Paxson
2016-02-13 : Slightly adjusted.
2015-11-12 : Added all picture sizes for Windows 10 compatibility.
#>
[CmdletBinding(SupportsShouldProcess=$true)]Param()
Function Test-Null($InputObject) { return !([bool]$InputObject) }
Function Set-ImageSize
{
<#
.SYNOPSIS
Resize image file.
.DESCRIPTION
The Set-ImageSize cmdlet to set new size of image file.
.PARAMETER Image
Specifies an image file. 
.PARAMETER Destination
Specifies a destination of resized file. Default is current location (Get-Location).
.PARAMETER WidthPx
Specifies a width of image in px. 
.PARAMETER HeightPx
Specifies a height of image in px. 
.PARAMETER DPIWidth
Specifies a vertical resolution. 
.PARAMETER DPIHeight
Specifies a horizontal resolution. 
.PARAMETER Overwrite
Specifies a destination exist then overwrite it without prompt. 
.PARAMETER FixedSize
Set fixed size and do not try to scale the aspect ratio. 
.PARAMETER RemoveSource
Remove source file after conversion. 
.EXAMPLE
PS C:\> Get-ChildItem 'P:\test\*.jpg' | Set-ImageSize -Destination "p:\test2" -WidthPx 300 -HeightPx 375 -Verbose
VERBOSE: Image 'P:\test\00001.jpg' was resize from 236x295 to 300x375 and save in 'p:\test2\00001.jpg'
VERBOSE: Image 'P:\test\00002.jpg' was resize from 236x295 to 300x375 and save in 'p:\test2\00002.jpg'
VERBOSE: Image 'P:\test\00003.jpg' was resize from 236x295 to 300x375 and save in 'p:\test2\00003.jpg'
.NOTES
Author: Michal Gajda
Blog : http://commandlinegeeks.com/
#>
[CmdletBinding(
SupportsShouldProcess=$True,
ConfirmImpact="Low"
)]
Param
(
[parameter(Mandatory=$true,
ValueFromPipeline=$true,
ValueFromPipelineByPropertyName=$true)]
[Alias("Image")]
[String[]]$FullName,
[String]$Destination = $(Get-Location),
[Switch]$Overwrite,
[Int]$WidthPx,
[Int]$HeightPx,
[Int]$DPIWidth,
[Int]$DPIHeight,
[Switch]$FixedSize,
[Switch]$RemoveSource
)
Begin
{
[void][reflection.assembly]::LoadWithPartialName("System.Windows.Forms")
#[void][reflection.assembly]::loadfile( "C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.Drawing.dll")
}
Process
{
Foreach($ImageFile in $FullName)
{
If(Test-Path $ImageFile)
{
$OldImage = new-object System.Drawing.Bitmap $ImageFile
$OldWidth = $OldImage.Width
$OldHeight = $OldImage.Height
if($WidthPx -eq $Null)
{
$WidthPx = $OldWidth
}
if($HeightPx -eq $Null)
{
$HeightPx = $OldHeight
}
if($FixedSize)
{
$NewWidth = $WidthPx
$NewHeight = $HeightPx
}
else
{
if($OldWidth -lt $OldHeight)
{
$NewWidth = $WidthPx
[int]$NewHeight = [Math]::Round(($NewWidth*$OldHeight)/$OldWidth)
if($NewHeight -gt $HeightPx)
{
$NewHeight = $HeightPx
[int]$NewWidth = [Math]::Round(($NewHeight*$OldWidth)/$OldHeight)
}
}
else
{
$NewHeight = $HeightPx
[int]$NewWidth = [Math]::Round(($NewHeight*$OldWidth)/$OldHeight)
if($NewWidth -gt $WidthPx)
{
$NewWidth = $WidthPx
[int]$NewHeight = [Math]::Round(($NewWidth*$OldHeight)/$OldWidth)
}
}
}
$ImageProperty = Get-ItemProperty $ImageFile
$SaveLocation = Join-Path -Path $Destination -ChildPath ($ImageProperty.Name)
If(!$Overwrite)
{
If(Test-Path $SaveLocation)
{
$Title = "A file already exists: $SaveLocation"
$ChoiceOverwrite = New-Object System.Management.Automation.Host.ChoiceDescription "&Overwrite"
$ChoiceCancel = New-Object System.Management.Automation.Host.ChoiceDescription "&Cancel"
$Options = [System.Management.Automation.Host.ChoiceDescription[]]($ChoiceCancel, $ChoiceOverwrite)
If(($host.ui.PromptForChoice($Title, $null, $Options, 1)) -eq 0)
{
Write-Verbose "Image '$ImageFile' exist in destination location � skiped"
Continue
} #End If ($host.ui.PromptForChoice($Title, $null, $Options, 1)) -eq 0
} #End If Test-Path $SaveLocation
} #End If !$Overwrite 
$NewImage = new-object System.Drawing.Bitmap $NewWidth,$NewHeight
$Graphics = [System.Drawing.Graphics]::FromImage($NewImage)
$Graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$Graphics.DrawImage($OldImage, 0, 0, $NewWidth, $NewHeight) 
$ImageFormat = $OldImage.RawFormat
$OldImage.Dispose()
if($DPIWidth -and $DPIHeight)
{
$NewImage.SetResolution($DPIWidth,$DPIHeight)
} #End If $DPIWidth -and $DPIHeight
$NewImage.Save($SaveLocation,$ImageFormat)
$NewImage.Dispose()
Write-Verbose "Image '$ImageFile' was resize from $($OldWidth)x$($OldHeight) to $($NewWidth)x$($NewHeight) and save in '$SaveLocation'"
If($RemoveSource)
{
Remove-Item $Image -Force
Write-Verbose "Image source '$ImageFile' was removed"
} #End If $RemoveSource
}
}
} #End Process
End{}
}
# Determine if local or domain account
$WhoAmI = whoami
$Prefix = $WhoAmI.split("{\}")[0]
If ($Prefix -eq (Hostname)){
$AccountType = "Local"
}
Else {
$AccountType = "Domain"
} 
# Get sid and photo for current user
If ($AccountType -eq "Domain"){
$user = ([ADSISearcher]"(&(objectCategory=User)(SAMAccountName=$env:username))").FindOne().Properties
$user_photo = $user.thumbnailphoto
$user_sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
If ((Test-Null $user_photo) -eq $false) {
Write-Verbose "Photo exists in Active Directory."
}
# If no image was found in profile, use one from network share.
Else {
Write-Verbose "No photo found in Active Directory for $env:username, using the default image instead"
$user_photo = 'C:\Resources\Profile Pics\User.png'
}
}
Else{
$user = New-Object System.Security.Principal.NTAccount($env:username)
$user_sid = ($user.Translate([System.Security.Principal.SecurityIdentifier])).Value
$user_photo = 'C:\Resources\Profile Pics\User.png'
}

# Set up image sizes and base path
$image_sizes = @(32, 40, 48, 96, 192, 200, 240, 448)
$image_mask = "Image{0}.jpg"
$image_base = "C:\Users\Public\AccountPictures"

# Set up registry
$reg_base = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AccountPicture\Users\{0}"
$reg_key = [string]::format($reg_base, $user_sid)
$reg_value_mask = "Image{0}"
If ((Test-Path -Path $reg_key) -eq $false) { New-Item -Path $reg_key } 

# Save images, set reg keys
Try {
ForEach ($size in $image_sizes) {
# Create hidden directory, if it doesn't exist
$dir = $image_base + "\" + $user_sid
If ((Test-Path -Path $dir) -eq $false) { $(mkdir $dir).Attributes = "Hidden" }
# Save photo to disk, overwrite existing files
$file_name = ([string]::format($image_mask, $size))
$path = $dir + "\" + $file_name
Write-Verbose " saving: $file_name"
If ($AccountType -eq "Domain"){
$user_photo | Set-Content -Path $path -Encoding Byte -Force
Get-ChildItem "$dir\$file_name" | Set-ImageSize -Destination $dir -WidthPx $size -HeightPx $size -Overwrite
}
Else {
Get-ChildItem 'C:\Resources\Profile Pics\User.png' | Set-ImageSize -Destination $dir -WidthPx $size -HeightPx $size
Rename-Item -Path "$dir\User.png" -NewName $file_name -Force
}
# Save the path in registry, overwrite existing entries
$name = [string]::format($reg_value_mask, $size)
$value = New-ItemProperty -Path $reg_key -Name $name -Value $path -Force
}
}
Catch {
Write-Error "Cannot update profile picture for $env:username."
Write-Error "Check prompt elevation and permissions to files/registry."
}